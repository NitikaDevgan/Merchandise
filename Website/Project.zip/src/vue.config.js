module.exports = {
    publicPath: ''
}
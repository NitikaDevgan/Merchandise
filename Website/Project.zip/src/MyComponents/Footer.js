import React from 'react'
import "./FooterStyle"
import "./Footer.css"

// import {
//     Box,
//     Container,
//     Row,
//     Column,
//     FooterLink,
//     Heading,
//   } from "./FooterStyle";
export const Footer = () => {
  return (
    // <div className="footer">
         
    // <div className="main-footer">
    //   <div className="container">
    //     <div className="row">
    //       {/* Column1 */}
    //       <div className="col">
    //         <h3 className="h4">About US</h3>
    //         <ui className="list-unstyled">
    //           <li>Aim</li>
    //           <li>Vision</li>
    //           <li>Testimonials</li>
    //         </ui>
    //       </div>
    //       <div className="col">
    //         <h3 className="h4">About US</h3>
    //         <ui className="list-unstyled">
    //           <li>Aim</li>
    //           <li>Vision</li>
    //           <li>Testimonials</li>
    //         </ui>
    //       </div>
    //       <div className="col">
    //         <h3 className="h4">About US</h3>
    //         <ui className="list-unstyled">
    //           <li>Aim</li>
    //           <li>Vision</li>
    //           <li>Testimonials</li>
    //         </ui>
    //       </div>
    //       {/* Column2 */}
    //       {/* <div className="col">
    //         <h3 className="h4">Contact Us</h3>
    //         <ui className="list-unstyled">
    //           <li>Uttar Pradesh</li>
    //           <li>Mumbai</li>
    //           <li>Indore</li>
    //         </ui>
    //       </div> */}
    //       {/* Column3 */}
    //       {/* <div className="col">
    //         <h3 className="h4">Social Media</h3>
    //         <ui className="list-unstyled">
    //           <li><i class="zmdi zmdi-facebook"></i>Fcaebook</li>
    //           <li><i class="zmdi zmdi-twitter"></i>Twitter</li>
    //           <li><i class="zmdi zmdi-instagram"></i>Instagram</li>
    //           <li><i class="zmdi zmdi-linkedin"></i>Linkedin</li>
    //         </ui>
    //       </div> */}
    //     </div>
    //     <hr />
    //     {/* <div className="row">
    //       <p className="col-sm">
    //         &copy;{new Date().getFullYear()} THICC MEMES | All rights reserved |
    //         Terms Of Service | Privacy
    //       </p>
    //     </div> */}
    //   </div>
    // </div>
    // </div>
    // <div className="footer-container">
    //     <nav>
    //       <ul>
    //         <li className="list">
    //           <Link to="/about">About</Link>
    //         </li>
    //         <li className="list">
    //           <Link to="/contact">Contact</Link>
    //         </li>
    //         <li className="list">
    //           <Link to="/terms">Terms of Use</Link>
    //         </li>
    //         <li className="list">
    //           <Link to="/privacy">Privacy Policy</Link>
    //         </li>
    //       </ul>
    //     </nav>
    // </div>

  <div className="r1">
  <div className="column" >
    <h2>About</h2>
    <ul>
      <li>Aim</li>
      <li>Vision</li>
      <li>Testimonials</li>
    </ul>
  </div>
  <div className="column" >
    <h2>Contact</h2>
    <ul>
      <li>Mumbai</li>
      <li>Uttar Pradesh</li>
      <li>Banglore</li>
    </ul>
  </div>
  <div className="column" >
    <h2>Social Media</h2>
    <ul>
      <li><i class="zmdi zmdi-facebook"></i>Facebook</li>
      <li><i class="zmdi zmdi-instagram"></i>Instagram</li>
      <li><i class="zmdi zmdi-twitter"></i>Twitter</li>
      <li><i class="zmdi zmdi-linkedin"></i>Linkedin</li>
    </ul>
  </div>
</div>
  )
}

//     <div><Box>
//     <h1 style={{ color: "green", 
//                  textAlign: "center", 
//                  marginTop: "-50px" }}>
//       Know More
//     </h1>
//     <Container>
//       <Row>
//         <Column>
//           <Heading>About Us</Heading>
//           <FooterLink href="#">Aim</FooterLink>
//           <FooterLink href="#">Vision</FooterLink>
//           <FooterLink href="#">Testimonials</FooterLink>
//         </Column>
//         <Column>
//           <Heading>Services</Heading>
//           <FooterLink href="#">Writing</FooterLink>
//           <FooterLink href="#">Internships</FooterLink>
//           <FooterLink href="#">Coding</FooterLink>
//           <FooterLink href="#">Teaching</FooterLink>
//         </Column>
//         <Column>
//           <Heading>Contact Us</Heading>
//           <FooterLink href="#">Uttar Pradesh</FooterLink>
//           <FooterLink href="#">Ahemdabad</FooterLink>
//           <FooterLink href="#">Indore</FooterLink>
//           <FooterLink href="#">Mumbai</FooterLink>
//         </Column>
//         <Column>
//           <Heading>Social Media</Heading>
//           <FooterLink href="#">
//             <i className="fab fa-facebook-f">
//               <span style={{ marginLeft: "10px" }}>
//                 Facebook
//               </span>
//             </i>
//           </FooterLink>
//           <FooterLink href="#">
//             <i className="fab fa-instagram">
//               <span style={{ marginLeft: "20px" }}>
//                 Instagram
//               </span>
//             </i>
//           </FooterLink>
//           <FooterLink href="#">
//             <i className="fab fa-twitter">
//               <span style={{ marginLeft: "10px" }}>
//                 Twitter
//               </span>
//             </i>
//           </FooterLink>
//           <FooterLink href="#">
//             <i className="fab fa-youtube">
//               <span style={{ marginLeft: "10px" }}>
//                 Youtube
//               </span>
//             </i>
//           </FooterLink>
//         </Column>
//       </Row>
//     </Container>
//   </Box></div>




const AuctionDetail = [
    {
        id:"1",
        Image: "./images/img6.jpg",
        heading:"Antique Table",
        span:"Popular",
        amount:"Starting from $1030",
        size:"Normal",
        Art:"1 piece",
        ArtImage: "./Actimg/img2.jpg",
        Art2:"Table",
        Art2Image:"./Images/img3.jpg"
        
    }  , 
        

    {
        id:"2",
        Image: "./Actimg/img4.jpg",
        heading:"Watch",
        span:"Popular",
        amount:"Starting from $1400",
        size:"Normal",
        Art:"1 piece",
        ArtImage: "./Actimg/img2.jpg",
        Art2:"Watch",
        Art2Image:"./Images/img5.jpg"
    },
    {
     id:"3",
    Image: "./Actimg/Img1.jpg",
    heading:"Art",
    span:"Popular",
    amount:"Starting from $2000",
    size:"Normal",
    Art:"1 piece",
    ArtImage: "./Actimg/img3.jpg",
    Art2:"Painting",
   Art2Image:"./Images/img2.jpg"
    },
    {
        id:"4",
       Image: "./Actimg/img3.jpg",
       heading:"Painting",
       span:"Popular",
       amount:"Starting from $3900",
       size:"Normal",
       Art:"1 Piece",
       ArtImage: "./Actimg/img3.jpg",
       Art2:"Painting",
      Art2Image:"./Images/img2.jpg"
       }
    
]
export default AuctionDetail

